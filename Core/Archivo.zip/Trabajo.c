/*---------------------------------------------------------------------------*/

/*                         M o d o     T R A B A J O                         */

/*---------------------------------------------------------------------------*/
/*
	Fecha inicialización	:	21/05/2022
	Fecha actualización 	:	22/12/2012
	Realizado por	    	:	C.E. Colombo
	Compilador utilizado	:	ST - Eclipse IDE
	Proyecto	    		:	Phenix 2022
	Archivo		    		: 	Main.c
	Versión	   	    		:	3.00.00
	Objetivo				:	Modo Trabajo
                                Se recibe el comando y se contesta con
							   los datos pedidos.
*/

#define  PosVariables   1   /*   	0 = Variables propias
									1 = Variables externas */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Variables.h"


extern void   	Clr_LCD(void);
extern void   	Print_LCD(uint8_t col,uint8_t fila,int8_t *cadena);
extern int8_t 	Teclado(void);
extern void   	Pongo_Hora(int8_t Hora, int8_t renglon);
extern void 	Armo_Cabecera(int8_t Usart);
extern void   	Tx_char(uint8_t tx_ch, int8_t Usart);  				/* Transmito un caracter */
extern void   	TX_Ack(int8_t Usart);
extern void 	TX_Nak(int8_t Usart);
extern void   	Inicializo_Rx(int8_t Usart);									/* Inicializo todas las variables para la rutina de recepción */
extern void  	Transfiero_Salidas(void);  									/* Mando datos a las placas de salida */
extern void 	Transmito_string(int16_t Usart, int8_t Flag_Check_Sun);
extern void 	Asig_Salidas(void);        									/* Asigno las salidas */
extern void 	Asig_Etiqueta(void);       									/* Asigno los tamanios a las etiquetadoras */
extern void   	Beep(void);													/* Activar Buzzer */
extern int8_t 	* mi_itoa(uint16_t numero, int8_t *buffer, int8_t Largo, int8_t saco_ceros);	// Convertir un entero en un dato ASCII de 5 caracteres
extern int16_t  mi_atoi(int8_t * s,int8_t Largo);							// Convertir una cadena ASCII de 5 caracteres en un entero
extern int8_t 	* mi_ltoa(uint32_t numero, int8_t *buffer, int8_t Largo,int8_t saco_ceros);	// Convertir un entero long en un dato ASCII de 10 caracteres
extern void     write_Pagina(void);
extern void 	Get_Num_Disco(void);										/* Pido el Número de Disco para control */
extern void     Write_Ram_BK(void);												// Guardo los datos de la ram en la back SRAM
extern void 	Proc_Rx_PC(uint16_t LenRx);
extern void 	StartReceivingUART_DMA_PC(void);
//extern void 	Error_Handler_UART(void);
extern void		Medicion(void);					// Medicion de los 8 canales del conversor AD
extern void 	Calculo_Velocidad(void);							// Calculo de la velocidad de la maquina

void  	Trabajo(void);
void  	Sort(void);                														/* Main del ordenamiento */
void  	Armo_salidas(void);        												/* Armo el string a enviar */
void  	Inicializo_Sort(int8_t Corte);     										/* Inicializo las variables para Sort */
void   	Borro_totalizadores(int8_t Modo);									/* Borro los totalizadores */
int8_t 	Veo_Salida(int8_t Linea, int8_t Tamanio);					/* arreglo las salidas a activar */
void  	Guardo_Datos(void);        												/* Guardo los datos y totalizo */
int16_t Calculo_Tamanio(int16_t Aux_Peso, int16_t Aux_Linea);		/* calculo el tamaño según el peso del fruto */
void 	Armo_Limites(void);														/* Cargo los límites a la Tabla_Limites */
void  	Trans_Totales(void);       												/* transfiero los totales a la PC */
void  	Paquete_Tamanio(int8_t Linea, int8_t Paquete);
void  	Paquete_Varios1(void);
void  	Paquete_Varios2(void);
void  	Paquete_Varios3(void);
void  	Paquete_Varios4(void);
void  	Paquete_Fruta(int8_t Linea, int8_t Paquete);

/*---------           Rutinas          ----------*/
/*---------------------------------------------------------------------------*/
/* Rutina   : Trabajo
*  Objetivo : Modo normal de trabajo
*  Entrada  :
*  Descripcion : Se realizan las tareas de selección de salidas según lo leido
*              y calculado de peso de las líneas, se transmiten las salidas
*              correspondientes y los datos a la PC.
*
 -----------------------------------------------------------------------------*/
void Trabajo(void)
	{
	uint8_t Dato[12];
    int16_t Contador = 0;
	int8_t 	x = 0;

    int8_t 	Flg_ACK = false;
    int8_t 	Flg_Totales = false;
    int8_t	Flg_Write = false;


    Flag_Trabajo = True;    									/* Pongo el flag de salida */
    Flg_Write = false;
	HAL_GPIO_WritePin(Modo_Trabajo_GPIO_Port, Modo_Trabajo_Pin,SET);/* Prendo el led de Modo Trabajo */
	Inicializo_Rx(Comu_PC);										/* Inicializo las variables de recepción */
	Inicializo_Rx(Comu_ESP);									/* Inicializo las variables de recepción */
	// Iniciar la recepción por DMA con detección de línea IDLE
	StartReceivingUART_DMA_PC();
//	StartReceivingUART_DMA_EMC();

	Clr_LCD();													/* Borro el LCD */
	Print_LCD(0,0,(int8_t *) "  Phenix 2025       ");
	Print_LCD(0,1,(int8_t *) " Trabajo   NPlat.   ");
	Print_LCD(0,2,(int8_t *) "V.Maq.     Nodo     ");
	Print_LCD(16, 2, (int8_t *) Config.Nodo);					// Pongo el Nº de nodo
	Time_Clock = 0;
	Time_Out_disp = 250;										/* Tiempo para sacar los datos al display */
	Pongo_Hora(false,0);

	/* Orden para pasar a modo trabajo a la  placa Salidas */
	HAL_GPIO_WritePin(Dir_485_PSalida_GPIO_Port, Dir_485_PSalida_Pin,SET);	/* Pongo la salidas PA11 = 1 (485) */
 	Time_Out_G = 0;												/* pongo el Time Out en 1 mseg. */
	/* string [Stx][N# Nodo (99 --> 0x63)][0][2][1][5][7][C] */
    Dato[0] = STX;
    Dato[1] = '6';
    Dato[2] = '3';
    Dato[3] = '0';
    Dato[4] = '2';
    Dato[5] = '1';
    Dato[6] = '5';
    Dato[7] = '7';
    Dato[8] = 'C';
    Dato[9] = Null;

    while(Time_Out_G != 0);					/* Espero la 485 */
    while(Dato[Contador]!=Null)
        {
    	Tx_char(Dato[Contador], Comu_PSalidas);
        Contador++;
        }
	HAL_GPIO_WritePin(Dir_485_PC_GPIO_Port, Dir_485_PSalida_Pin,RESET);	/* Pongo la salidas PA11 = 0 (485) */

	Beep();
	NodoOrRe[0] = 0x38;						/* Cargo la dirección del nodo que recibe */
	NodoOrRe[1] = 0x30;
	NodoOrRe[2] = Null;
    Contador = 0;

	Velocidad_medida = 0;
    M_Trabajo.Velocidad  = 0;
	for(x = 0; x < 12; x++)
    	Dato[x] = Null;

    Dato[0] = ' ';
    Dato[1] = '0';
    Dato[2] = '.';
    Dato[3] = '0';
    Dato[4] = Null;


    if(Flag_Primer_ingreso == false)						/* Si es la primera vez salteo la transmisión de un ACK */
    	{
		TX_Ack(Comu_PC);									/* En los próximas cambios transmito un ACK a la PC */
    	Beep();
		}
	Flag_Primer_ingreso = false;
    if(HAL_GPIO_ReadPin(C_S_Display_GPIO_Port,C_S_Display_Pin) == 0)/* Si está puesto el Jumper, habilito el display y teclado */
    	Flg_Display = true;
    else
    	Flg_Display = false;

    Inicializo_Sort(0);

	while (Flag_Trabajo==True)								// sin un comando que lo cambie no salgo
        {													// si recibí algo el flag pasa a True
        if((Flag_Rx_DMA_PC == true))					    // si es por la serie DMA la atiendo
        	{
           	Proc_Rx_PC(RxDataLen_PC);					    // Analizo el string recibido
           	StartReceivingUART_DMA_PC();				    // Habilito el DMA PC
            }
        if((Comunica_PC.flg_rx == true))				    // si la recepción fue buena, la atiendo
        	{
           	Print_LCD(0,3,(int8_t *)"R.Comando:          ");
    		switch(Comando_recibido)					    // analizo el comando recibido
				{       /* Acciones de la CPU */
				case Sort_Off:          				    // Modo Trabajo Off
            	    	Beep();
						Flag_Trabajo = False;
						Flg_ACK = false;
    	               	Print_LCD(11,3,(int8_t *)"Sort OFF");
			       	    break;
					case Esc:               				// Dejar de hacer una tarea
					    Beep();
    	               	Print_LCD(11,3,(int8_t *)"Escape ");
						Flg_ACK = true;
	                   	break;
					case C_Limites:         				// Actualizo o cargo los límites
						Armo_Limites();						// Guardo los límites
						Flg_ACK = true;
    	               	Print_LCD(11,3,(int8_t *)"Limites");
				        break;
					case Asig_Salida:       				// Actualizo estructura de salidas E_Salidas
						Asig_Salidas();						// Guardo las salidas
						Flg_ACK = true;
						Print_LCD(11,3,(int8_t *)"Salidas");
						break;
					case Asig_Etiq:         				// Actualizo matriz de etiquetadoras
						Asig_Etiqueta();					// Guardo las etiquetadoras
						Flg_ACK = true;
    	               	Print_LCD(11,3,(int8_t *)"Etique.");
				        break;
				    case Acumuladores:      				// Transfiero totales a la PC
				    	Flg_Totales = true;
				    	Print_LCD(11,3,(int8_t *)"Acumula");
					    break;
	                case Retransmite:
	                    Transmito_string(Comu_PC,false);	// Re transmito y calculo en check sum
	                	Print_LCD(11,3,(int8_t *)"Retrans");
						break;
	                case Cambio_Lote:
					    Inicializo_Sort(1);
						Flg_ACK = true;
    	               	Print_LCD(11,3,(int8_t *)"CamLote");
		               	break;
				    case Estado:
				        if((Flag_Maq_Enable  == true))  	// estoy? en condiciones de pasar fruta
						    {
				        	Flg_ACK = true;					// ACK     ==> máquina en condiciones
						    }
	               	    else
		               	    {
			               	TX_Nak(Comu_PC);				// NACK    ==> No se puede pasar fruta
				            }
				    	Print_LCD(11,3,(int8_t *)"Estado ");
					    break;
					case Get_N_Disco:
						Get_Num_Disco();					// Transmito el número de disco para control
				    	Flg_ACK = True;
				 		Print_LCD(11,3,(int8_t *)"Num.Dis");
						break;
					/* Si es un Nack, Can, Ack, no hago nada */
					case ACK_1:
					case NAK_1:
					case CAN_1:
				 		Print_LCD(11,3,(int8_t *)"CAN");
						break;
					case No_nodo:							/* No es para este nodo */
                    	Print_LCD(11,3,(int8_t *)"No nodo");
		               	break;
					default:                				/* Comando desconocido */
    	               	Print_LCD(11,3,(int8_t *)"descono");
		    	        break;
		            }   		/* cierro el swicth */

				if(Comunica_PC.errores_txrx != 0)
					Print_LCD(0,3,(int8_t *)"Error Recepcion     ");

				Inicializo_Rx(Comu_PC);						/* Inicializo las variables de recepción */

            }						/* Cierro el if de la recepción */
            Medicion();
            if(Flag_SecuenEje == true)						// Si recibí el pulso de sincronismo hago el proceso general
            	{
            	Transfiero_Salidas();						/* Transmito el dato de las salidas a activar por DMA */
            	Guardo_Datos();								/* Guardo los datos que me interesan y actualizo totales */
            	Sort();										/* armo la cola de fruta y armo las salidas */
            	Flag_SecuenEje = false;
            	}
            else
                {
                 if(Flg_Totales == true)
            	    {
            	    Flg_Totales = false;
    	    	    Trans_Totales();							/* Transfiero los totales a la PC */
            	    }

                 if(Flg_ACK == True)
				    {
				    TX_Ack(Comu_PC);
				    Flg_ACK = False;
				    }

                 if((Flg_Write == true) && (M_Trabajo.Velocidad == 0))
            	    {
                     Write_Ram_BK();								// Guardo los datos de la ram CCM en la Ram BackUp
           	         write_Pagina();								/* Grabo en la Flash */
            	    Flg_Write = false;
            	    Print_LCD(11,3,(int8_t *)"GraboDa");
            	    }

                Calculo_Velocidad();							// Calculo de la velocidad de la maquina
                M_Trabajo.Velocidad = Velocidad_medida;
                Print_LCD(6, 2, (int8_t *) Dato_Velo);			// Pongo la velocidad de la máquina
                }
        }           /* cierro el while principal */
	HAL_GPIO_WritePin(Modo_Trabajo_GPIO_Port, Modo_Trabajo_Pin,RESET);	/* Apago el led de Modo Trabajo */
	}
/*---------------------------------------------------------------------------------------*/
/*									Rutinas generales									 */
/*---------------------------------------------------------------------------------------*/
/* Rutina   : Inicializo_Sort(Corte)
*  Objetivo : Proceso de ordenamiento de frutas
*  Entrada  : Corte = 0 --> inicializo todas las variables y los punteros de la cola
			  Corte = 1 --> borro los totalizadores y transmito un Ack (corte de lote)
*  Descripcion :   Inicializo Variables de totales
    Borro_totalizadores(Corte)
    struct reg_Trabajo ==> M_Trabajo
        {
        uint32_t   TotalKg_Tamano[Max_Tamanos][MaxLineas];		Total de Kg Tamano X Línea
        uint32_t   TotalKg_Calidad[16];						 	Total de Kg por calidad
        uint32_t   TotalKg_Linea[MaxLineas];					Total de Kg por linea
        uint32_t   Tot_Plato_Vacio[MaxLineas];					Total de platillos vacios por línea
        uint32_t   Tot_Platillos[MaxLineas];					Total de platillos por línea
        uint32_t   Tot_Frutos_Tamanos[Max_Tamanos][MaxLineas];	Total de frutos por línea
        uint32_t   Total_Frutos[MaxLineas];					 	Total de frutos por línea
        int8_t     Velocidad;									Velocidad de máquina
        };
           Inicializo Matriz de trabajo
           armar tabla de asignación de salidas con calidades
*
-----------------------------------------------------------------------------*/
void Inicializo_Sort(int8_t Corte)
    {
	int16_t j;
	int8_t x;

    N_Transferencia = 0;
     /* inicializo los totalizadores del sistema de control de peso */
	Borro_totalizadores(Corte);

    if(Corte == 0)
		{
		/* Inicializo punteros */
		 Flag_IndicesOk = False;
	     Puntero_Dato = 0;

		 /* inicializo las variables del sistema sort */
		 /* borro los totalizadores de salidas */
		 /* inicializo la variable de la asignación de Bandejas */
	     for(j = 0; j < Config.n_salidas; j++)
		    {
     		Tot_Frut_Salidas[j] = 0;
	        Bandeja_Act[j]=0;
			for(x = 0; x < MaxLineas; x++)
				{
	            Flag_General[x][j]= False;
		        Indice[x][j]= 1;
			    }
	        }

		 /* inicializo la variable de la asignación de salidas, válvulas */
	    for(j = 0; j < Tot_Valvulas; j++)
		    {
			for(x = 0; x < MaxLineas; x++)
				{
				Val_Salida[x][j]= 0;
				Bandeja[x][j]= 0;
				}
	        Valvula[j]=0;
		    }

			/* Variables etiquetadoras */
	    Flag_IndicesOk_E = False;
		Puntero_Dato_E = 0;

	    for(j = 0; j < Max_Tamanos; j++)
		    {
			for(x = 0; x < MaxLineas; x++)
				Tamano_E[x][j] = 0;
	        Sal_Etiqueta[j] = 0;
		    }

	    for(j = 0; j< Config.n_etique; j++)
		    {
			for(x = 0; x < MaxLineas; x++)
				{
	            Flag_General_E[x][j] = False;
		        Indice_E[x][j] = 1;
			    }
	        }

		Armo_salidas();
		}
    }
/*---------------------------------------------------------------------------*/
/* Rutina   : Borro_totalizadores
*  Objetivo : Proceso de ordenamiento de frutas
*  Entrada  : 	Modo = 0, pongo todo a cero.
				Modo != 0, solo transfiero los datos a la estructura de transmisión
						y pongo a cero la estructura de trabajo

*  Descripcion :
    struct reg_Trabajo ==> M_Trabajo = Aux_Trabajo
        {
        uint32_t   TotalKg_Tamano[Max_Tamanos][MaxLineas];		Total de Kg Tamano X Línea
        uint32_t   TotalKg_Calidad[16];						 	Total de Kg por calidad
        uint32_t   TotalKg_Linea[MaxLineas];					Total de Kg por linea
        uint32_t   Tot_Plato_Vacio[MaxLineas];					Total de platillos vacios por línea
        uint32_t   Tot_Platillos[MaxLineas];					Total de platillos por línea
        uint32_t   Tot_Frutos_Tamanos[Max_Tamanos][MaxLineas];	Total de frutos por línea
        uint32_t   Total_Frutos[MaxLineas];					 	Total de frutos por línea
        int8_t     Velocidad;									Velocidad de máquina
        };
           Inicializo Matriz de trabajo
           armar tabla de asignación de salidas con calidades
*
-----------------------------------------------------------------------------*/
void  Borro_totalizadores(int8_t Modo)
    {
	int8_t j;
	int8_t x;


    if(Modo == 0)
		{
     	/* inicializo los totalizadores del sistema de control de peso */
	     for(j = 0; j < MaxLineas; j++)
    		{
	        for(x = 0; x < Max_Tamanos; x++)
    	        {
        	    M_Trabajo.TotalKg_Tamano[x][j] = 0;
            	M_Trabajo.Tot_Frutos_Tamanos[x][j] = 0;
	            }
    	    M_Trabajo.Total_Frutos[j] = 0;
        	M_Trabajo.Tot_Platillos[j] = 0;
	        M_Trabajo.Tot_Plato_Vacio[j] = 0;
    	    M_Trabajo.TotalKg_Linea[j] = 0;
        	}
        }

     for(j = 0; j < MaxLineas; j++)
   		{
        for(x = 0; x < Max_Tamanos; x++)
   	        {
   	        Aux_Trabajo.TotalKg_Tamano[x][j] = M_Trabajo.TotalKg_Tamano[x][j];
       	    M_Trabajo.TotalKg_Tamano[x][j] = 0;
       	    Aux_Trabajo.Tot_Frutos_Tamanos[x][j] = M_Trabajo.Tot_Frutos_Tamanos[x][j];
           	M_Trabajo.Tot_Frutos_Tamanos[x][j] = 0;
            }
   	    Aux_Trabajo.Total_Frutos[j] = M_Trabajo.Total_Frutos[j];
   	    M_Trabajo.Total_Frutos[j] = 0;
       	Aux_Trabajo.Tot_Platillos[j] = M_Trabajo.Tot_Platillos[j];
       	M_Trabajo.Tot_Platillos[j] = 0;
        Aux_Trabajo.Tot_Plato_Vacio[j] = M_Trabajo.Tot_Plato_Vacio[j];
        M_Trabajo.Tot_Plato_Vacio[j] = 0;
   	    Aux_Trabajo.TotalKg_Linea[j] = M_Trabajo.TotalKg_Linea[j];
   	    M_Trabajo.TotalKg_Linea[j] = 0;
       	}
  	 Aux_Trabajo.Velocidad = M_Trabajo.Velocidad;
	}
/*---------------------------------------------------------------------------*/
/* Rutina   : Armo_salidas
*  Objetivo : Armar el string a transmitir a las placas de salida
*  Entrada  :
*  Descripcion : El string debe ser:
				[SI][Largo][comando][Placa 1][Placa 2]........[Placa N][Etiq.1]...[Etiq.4][ck]
    donde   ==> SI      = 0x0F
                Largo   = Longitud del string
                comando = 0x16
                Placa 1 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                Placa 2 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                .
                .
                Placa N = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                Etiq. 1 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                .
                Etiq. 4 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                ck      = check sum
*
*				Se modifica el 17/04/2017 y se agregan de 1 a 4 placas de salida
*				para indicar el sistema de bandeja, estas están incertadas ante
*				de las salidas. Son 4 placas porque el sistema acepta hasta 32
*				salidas y si tenemos el máximo de salidas cada placa maneja 8
*				salidas.
Por lo tanto==> SI      = 0x0F
                Largo   = Longitud del string
                comando = 0x16
                Placa 1 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                Placa 2 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                .
                .
                Placa N = 1 bit para cada válvula, 0 = desactivada, 1 = activada

				Bandeja 1 = 1 bit para cada salida, 0 = desactivada, 1 = activada
				.
				Bandeja 4 = 1 bit para cada salida, 0 = desactivada, 1 = activada

                Etiq. 1 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                .
                Etiq. 4 = 1 bit para cada válvula, 0 = desactivada, 1 = activada
                ck      = check sum
*

-----------------------------------------------------------------------------*/
void Armo_salidas(void)
    {
	int16_t x = 0;
	int16_t j;
	int16_t largo = 0;
	int16_t tot_val;
	int8_t tot_Band;
	int8_t tot_Etiq;
	int16_t redondeo;
    uint16_t y;

    /* Inicializo el buffer dr transmisión y la cantidad de bytes a transmitir */
	for(j = 0; j < 43; j++)   												/* Limpio el buffer de transmisión 3 Cabecera 32 Sal. + 4 Band. + 4 Etiq. */
		*(Comunica_PSal.buf_tx_Sal + j) = Null;

	*(Comunica_PSal.buf_tx_Sal) = 1;
	Comunica_PSal.tot_Tx = 1;               			/* cant. de bytes a transmitir */

	/* Cargo cabecera y comando */
	*(Comunica_PSal.buf_tx_Sal) = SI;  					/* comando 'SI'  inicio de transacción */
    y = *(Comunica_PSal.buf_tx_Sal);     					/* calculo el check sum */

    *(Comunica_PSal.buf_tx_Sal + 2) = 0x16;    		/* comando para las placas de salidas */
    y = y + *(Comunica_PSal.buf_tx_Sal + 2); 			/* calculo el check sum */

    /* Comienzo a cargar los datos a transmitir */
    tot_val = Config.n_salidas * Config.n_lineas;
    /* OJO hay que completar para que sea multiplo de 8 */
    redondeo = tot_val % 8;
    if(redondeo != 0)
        tot_val = tot_val + 8 - redondeo;

    for(j = 0; j < tot_val; j++)
        {
        switch(x)                   											/* x = posicion del bit */
            {
            case 0:
                if(Valvula[j] == 0) 										/* inicializo el byte a llenar */
                    {
                    *(Comunica_PSal.buf_tx_Sal + 3 + largo) = 0x00;
                    }
                else
                    {
                    *(Comunica_PSal.buf_tx_Sal + 3 + largo)=0x01;
                    }
                break;
            case 1:
                if(Valvula[j] != 0)
                    {
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x02;
                    }
               break;
            case 2:
                if(Valvula[j] != 0)
                	{
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x04;
                	}
                break;
            case 3:
                if(Valvula[j] != 0)
                    {
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x08;
                    }
                break;
            case 4:
                if(Valvula[j] != 0)
                    {
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x10;
                    }
                break;
            case 5:
                if(Valvula[j] != 0)
                    {
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x20;
                    }
                break;
            case 6:
                if(Valvula[j] != 0)
                    {
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x40;
                    }
                break;
            case 7:
                if(Valvula[j] != 0)
                    {
                	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x80;
                    }
                break;
            }
        x++;

        if(x > 7)
            {
             x = 0;
             y = y + *(Comunica_PSal.buf_tx_Sal + 3 + largo); /* calculo el check sum */
             largo ++;
            }
        }

     	/* 	si hay que manejar bandeja debo llenar de "1" ó "0"  a n bytes según la
        	salida que haya que activar.
        	Máximo 4 placas bandeja .
    	*/

    if(Config.modo_bandeja == 1)
    	{
        tot_Band = Config.n_salidas;
        /* OJO hay que completar para que sea multiplo de 8 */
        redondeo = tot_Band % 8;
        if(redondeo != 0)
        	tot_Band = tot_Band + 8 - redondeo ;

    	x = 0;
        for(j = 0; j < tot_Band; j ++)
        	{
            switch(x)                   	/* x = posicion del bit */
            	{
                case 0:
                	if(Bandeja_Act[j] == 0) /* inicializo el byte a llenar */
                    	{
                        *(Comunica_PSal.buf_tx_Sal + 3 + largo)=0x00;
                        }
 					else
                        {
                        *(Comunica_PSal.buf_tx_Sal + 3 + largo)=0x01;
                        }
                    break;
     			case 1:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x02;
                        }
                    break;
                case 2:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x04;
                        }
                    break;
                case 3:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x08;
                        }
                    break;
                case 4:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x10;
                        }
                    break;
                case 5:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x20;
                        }
                    break;
                case 6:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x40;
                        }
                    break;
                case 7:
                    if(Bandeja_Act[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x80;
                        }
                    break;
                }
     		x++;

            if(x > 7)
            	{
                x = 0;
                y = y + *(Comunica_PSal.buf_tx_Sal + 3 + largo); /* calculo el check sum */
                largo ++;
                }
   			}
 		}
        /* si hay etiquetadora debo llenar de "1" ó "0"  a n bytes según la cantidad
        de etiquetadoras que hay y la cantidad de líneas que tiene el sistema.
        Máximo 4 etiquetadoras y 6 líneas, son 24 salidas ==> 3 placas de 8 salidas
        c/u. por lo tanto 'largo' se debe inrementar en 3 y llenar los tres bytes
        con los datos correspondientes.
    	*/

    if(Config.n_etique != 0)
        {
        tot_Etiq = Config.n_etique * Config.n_lineas;

        /* OJO hay que completar para que sea multiplo de 8 */
        redondeo = tot_Etiq % 8;
        if(redondeo != 0)
            tot_Etiq = tot_Etiq + 8 - redondeo ;

        x = 0;
        for(j = 0; j < tot_Etiq; j++)
        	{
            switch(x)                   		/* x = posicion del bit */
            	{
                case 0:
                	if(Sal_Etiqueta[j] == 0) 	/* inicializo el byte a llenar */
                		{
                        *(Comunica_PSal.buf_tx_Sal + 3 + largo)=0x00;
                        }
                	else
                        {
                        *(Comunica_PSal.buf_tx_Sal + 3 + largo)=0x01;
                        }
                    break;
                case 1:
                    if(Sal_Etiqueta[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x02;
                        }
                    break;
                case 2:
                    if(Sal_Etiqueta[j] != 0)
                    	{
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x04;
                    	}
                    break;
                case 3:
                    if(Sal_Etiqueta[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x08;
                        }
                    break;
                case 4:
                    if(Sal_Etiqueta[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x10;
                        }
                    break;
                case 5:
                    if(Sal_Etiqueta[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x20;
                        }
                    break;
                case 6:
                    if(Sal_Etiqueta[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x40;
                        }
                    break;
                case 7:
                    if(Sal_Etiqueta[j] != 0)
                        {
                    	*(Comunica_PSal.buf_tx_Sal + 3 + largo)= *(Comunica_PSal.buf_tx_Sal + 3 + largo) | 0x80;
                        }
                   break;
            }
            x++;

                if(x > 7)
                    {
                     x = 0;
                     y = y + *(Comunica_PSal.buf_tx_Sal + 3 + largo); /* calculo el check sum */
                     largo ++;
                    }
                }
            }

    largo ++;    																					/* agrego al largo el comando y el ck */
    largo ++;
    *(Comunica_PSal.buf_tx_Sal + 1) = largo;   							/* longitud del paquete */
    y = y + *(Comunica_PSal.buf_tx_Sal + 1);          						/* calculo el check sum */
    *(Comunica_PSal.buf_tx_Sal + largo  +1)= y;							/* guardo el check sum */
    Comunica_PSal.tot_Tx = largo  +2;               					/* cant. de bytes a transmitir */
    }

/*---------------------------------------------------------------------------*/
/* Rutina   : Sort
*  Objetivo : Proceso de ordenamiento de frutas
*  Entrada  :
*  Descripcion :1.- Incrementamos punteros
                2.- Verifico la cola de salidas y armo los datos del próximo paquete
				3.- Verifico las etiquetadoras y armo los datos del próximo paquete
				4.- Armo el paquete de salidas y etiquetadoras para la próxima vuelta
-----------------------------------------------------------------------------*/
void Sort(void)
    {
	int16_t j;       										/* Número de salida */
	int16_t x;       										/* Número de línea */
	int16_t y;       										/* auxiliar, calculo del N# de válvula */
	int16_t aux;
	int16_t aux1;
	int16_t Flag_Bandeja[Salidas];							/* flag que indica que active la salida de bandejas */

	for(x = 0; x < Config.n_salidas; x ++)
		Flag_Bandeja[x] = False;							/* Pongo el flag en 0 */

	M_Trabajo.Velocidad = Velocidad_medida;
	if(M_Trabajo.Velocidad != 0)							/* si la máquina está parada, no hago nada */
        {                       							/* Manejo de las salidas */
        Puntero_Dato++;         							/* incremento mi puntero para guardar el próximo
															   dato y si es igual a la máxima distancia lo hago = 0 */
        if(Puntero_Dato > Config.DisBox[((Config.n_salidas) - 1)])
            Puntero_Dato=0;

        if(Flag_IndicesOk == False)
            {   											/* no se inicializaron todos los índices */
															/* Voy incrementando los punteros habilitados y activando salidas
																si corresponde */
            for(x = 0; x < Config.n_lineas;x++)      		/* barro por linea */
                {
                for(j = 0; j < Config.n_salidas; j ++)		/* barro por salidas */
                    {
                    if(Flag_General[x][j] == True)
                        {
                        Indice[x][j] ++;
                        aux = Indice[x][j];					/* distancia */
                        y = (j * Config.n_lineas) + x;		/* calculo el N# de válvula */
						if(Val_Salida[x][aux] == (j + 1))
							{
                            Valvula[y] = 1;					/* Activo la salida */
                          	if(Bandeja[x][aux] == (j + 1))	/* Veo si tengo que activar la bandeja */
                          		{
	 							if(Flag_Bandeja[j] == False)/* Verifico el flag de la bandeja */
		 							{
			                        Bandeja_Act[j] = 1;		/* Activo la bandeja de la salida J */
									Flag_Bandeja[j] = True;	/* Pongo el flag en 1 */
									}
								}
                            }
                        else
                            {
                            Valvula[y] = 0;
							if(Flag_Bandeja[j] == False)	/* Verifico el flag de la bandeja */
                       			Bandeja_Act[j] = 0;			/* Apago la bandeja */
                            }
                        }
                    }
                }

            /* Voy habilitando los punteros a medida que llegan */
            for(x = 0; x < Config.n_lineas;  x ++)        	/* barro por linea */
                {
                for(j = 0; j < Config.n_salidas; j ++)		/* barro por salidas */
                    {
                    if(Puntero_Dato == ((Config.DisBox[j]) - 1))
                        {
                        Flag_General[x][j] = True;
                        if(Config.n_salidas - 1 == j)
                            Flag_IndicesOk = True;
                        y = (j * Config.n_lineas) + x;		/* calculo el N# de válvula */
                        aux = Indice[x][j];
						if(Val_Salida[x][aux] == (j + 1))
                            {
                            Valvula[y] = 1;					/* Activo la salida */
                        	if(Bandeja[x][aux] == (j + 1))	/* Veo si tengo que activar la bandeja */
                        		{
	 							if(Flag_Bandeja[j] == False)/* Verifico el flag de la bandeja */
		 							{
			                        Bandeja_Act[j] = 1;		/* Activo la bandeja de la salida J */
									Flag_Bandeja[j] = True;	/* Pongo el flag en 1 */
									}
								}
                            }
                        else
                            {
                            Valvula[y] = 0;
							if(Flag_Bandeja[j] == False)	/* Verifico el flag de la bandeja */
		                       	Bandeja_Act[j] = 0;			/* Apago la bandeja */
                            }
                        }
                    }
                }
            }
        else    /* Trabajo propiamente dicho */
            {
            for(x = 0; x < Config.n_lineas; x++)         	/* barro por linea 		--> x */
                {
                for(j = 0; j < Config.n_salidas; j++)    	/* barro por salidas 	--> j */
                    {
                    if(Indice[x][j] >= Config.DisBox[((Config.n_salidas) - 1)])
                        {
                        Indice[x][j] = 0;
                        }
                    else
                        {
                        Indice[x][j]++;
                        }
                    y = (j * Config.n_lineas) + x;    		/* calculo el N# de válvula */
                    aux = Indice[x][j];
					if(Val_Salida[x][aux] == (j + 1))
                        {
                        Valvula[y] = 1;						/* Activo la salida */
 						if(Bandeja[x][aux] == (j + 1))		/* Veo si tengo que activar la bandeja */
 							{
 							if(Flag_Bandeja[j] == False)	/* Verifico el flag de la bandeja */
	 							{
		                        Bandeja_Act[j] = 1;			/* Activo la bandeja de la salida J */
								Flag_Bandeja[j] = True;		/* Pongo el flag en 1 */
								}
							}
                        }
                    else
                        {
                        Valvula[y] = 0;
						if(Flag_Bandeja[j] == False)		/* Verifico el flag de la bandeja */
		                   	Bandeja_Act[j] = 0;				/* Apago la bandeja */
                        }
                    }
                }
            }

        /* Manejo de las Etiquetadoras */
        if(Config.n_etique != 0)
            {
            Puntero_Dato_E++;      							/* incremento mi puntero para guardar el próximo
															   dato y si es igual a la máxima distancia lo hago
															   = 0 */
            if(Puntero_Dato_E > Config.DistEtiq[((Config.n_etique) - 1)])
                Puntero_Dato_E = 0;

            if(Flag_IndicesOk_E == False)
                {   										/* no se inicializaron todos los índices */
															/* Voy incrementando los punteros habilitados y activando salidas
																si corresponde */
                for(x = 0; x < Config.n_lineas; x++)      	/* barro por linea */
                    {
                    for(j = 0; j < Config.n_etique; j++)  	/* barro por etiquetadora */
                        {
                        if(Flag_General_E[x][j] == True)
                            {
                            Indice_E[x][j]++;
                            aux = Indice_E[x][j];
                            y = (j * Config.n_lineas)+ x;	/* calculo el N# de etiquetadora */
                            aux1 = Tamano_E[x][aux];       	/* Valor del tamanio */
                            if(E_Etiqueta_CCM[j][x][aux1] != 0)
                                {
                                 Sal_Etiqueta[y] = 1;
                                }
                            else
                                {
                                 Sal_Etiqueta[y] = 0;
                                }
                            }
                        }
                    }

                /* Voy habilitando los punteros a medida que llegan */
                for(x = 0; x < Config.n_lineas; x++)      	/* barro por linea */
                    {
                    for(j = 0; j < Config.n_etique; j++)  	/* barro por etiquetadoras */
                        {
                        if(Puntero_Dato_E == ((Config.DistEtiq[j]) - 1))
                            {
                            Flag_General_E[x][j] = True;
                            if(((Config.n_etique) - 1) == j)
                                Flag_IndicesOk_E = True;

                            y = (j * Config.n_lineas)+ x;	/* calculo el N# de salida */
                            aux = Indice_E[x][j];
                            aux1 = Tamano_E[x][aux];        /* Valor del tamanio */
                            if(E_Etiqueta_CCM[j][x][aux1] != 0)
                                {
                                Sal_Etiqueta[y] = 1;
                                }
                            else
                                {
                                Sal_Etiqueta[y] = 0;
                                }
                            }
                        }
                    }
                }
            else    				/* Trabajo propiamente dicho */
                {
                for(x = 0; x < Config.n_lineas; x++)    	/* barro por linea */
                    {
                    for(j = 0; j < Config.n_etique; j++)	/* barro por etiquetadoras */
                        {
                        if(Indice_E[x][j] >= Config.DistEtiq[((Config.n_etique) - 1)] )
                            {
                            Indice_E[x][j] = 0;
                            }
                        else
                            {
                            Indice_E[x][j]++;
                            }
                        y = (j * Config.n_lineas) + x;		/* calculo el N# de etiquetadora */
                        aux = Indice_E[x][j];
                        aux1 = Tamano_E[x][aux];        	/* Valor del tamanio */
                        if(E_Etiqueta_CCM[j][x][aux1] != 0)
                            {
                            Sal_Etiqueta[y] = 1;
                            }
                        else
                            {
                            Sal_Etiqueta[y] = 0;
                            }
                        }
                    }
                }
            }
        Armo_salidas();										/* preparo para la próxima medición */
        }
    }

/*---------------------------------------------------------------------------*/
/* Rutina   : Veo_Salida
*  Objetivo : Cambiar si hace falta la salida en curso y llevar la cantidad de frutos por salida
*  Entrada  :
*  Descripcion :
    struct reg_Sal  E_Salidas[8][21] -  E_Salidas[MaxLineas][Max_Tamanos]
        {
        int8_t   Salida_Actual;       Salida en curso
        int8_t   Total_frutos;        Cantidad de frutos de la salida en curso
        int8_t   Puntero;             Puntero a la póxima salida
        int8_t   Cant_Boxes;          Cantidad de salidas asociadas, 1 a 4
        int8_t   Sal[4];              Primer salida asociada
        int8_t   Tot_Frutos_Box[4];   Total de frutos de cada salida salida
        };
*
*		Si el Flag "modo_bandeja != 0"(1) Modo Bandeja
*		Se deben verificar todas las salidas afectadas a la misma salida y se llega a la
*		cantidad de frutos, se realiza el cambio de salida y se activa la señal correspondiente.
*		Se actualizan los totales de fruta en todas las salidas afectadas.
*		Se agrega una nueva variable Tot_Frut_Salidas[Salidas] donde se lleva la
*		suma de frutos de la misma salida y se usa para comparar con la cantidad
*		pre determinada
*
-----------------------------------------------------------------------------*/
int8_t Veo_Salida(int8_t Linea, int8_t Tamanio)
    {
	int16_t x;
	int16_t resultado;
	int16_t x_linea;
	int16_t X_Box;

	Bandeja_Aux = 0; 																			/* pongo a cero el dato de la bandeja */

    if(Tamanio == 0)
		resultado = 0;
	else
		{
	    if(Config.modo_bandeja == 0)															/* Sin Bandeja control normal por linea */
			{
	    	E_Salidas_CCM[Linea][Tamanio].Total_frutos--;        									/* decremento el % actual */
			if(E_Salidas_CCM[Linea][Tamanio].Total_frutos <= 0)										/* si el % es < a cero, cambio la salida actual */
				{
				E_Salidas_CCM[Linea][Tamanio].Puntero++;        									/* incremento el puntero  */
			    if(E_Salidas_CCM[Linea][Tamanio].Puntero < E_Salidas_CCM[Linea][Tamanio].Cant_Boxes)
				    {
					x = E_Salidas_CCM[Linea][Tamanio].Puntero;
	            	}
			    else
				    {
			    	E_Salidas_CCM[Linea][Tamanio].Puntero=0;
	        	    x = 0;
		        	}
			    E_Salidas_CCM[Linea][Tamanio].Salida_Actual = E_Salidas_CCM[Linea][Tamanio].Sal[x];
			    E_Salidas_CCM[Linea][Tamanio].Total_frutos = E_Salidas_CCM[Linea][Tamanio].Tot_Frutos_Box[x];
			    }
			}
		else
			{
			E_Salidas_CCM[Linea][Tamanio].Total_frutos ++;        									/* Incremento la Cantidad de frutos */
			Tot_Frut_Salidas[E_Salidas_CCM[Linea][Tamanio].Salida_Actual] ++;						/* Incremento la Cantidad de frutos por salida */

			if(Tot_Frut_Salidas[E_Salidas_CCM[Linea][Tamanio].Salida_Actual] >= E_Salidas_CCM[Linea][Tamanio].Tot_Frutos_Box[E_Salidas_BK[Linea][Tamanio].Puntero])
				{
				E_Salidas_CCM[Linea][Tamanio].Puntero ++;        									/* incremento el puntero  */
			    if(E_Salidas_CCM[Linea][Tamanio].Puntero < E_Salidas_CCM[Linea][Tamanio].Cant_Boxes)  	/* Me fijo que el puntero no supere */
					x = E_Salidas_CCM[Linea][Tamanio].Puntero;									  	/* la cantidad de salidas activas */
		    	else																			/* x es el valor actualizado del puntero */
					{
		    		E_Salidas_CCM[Linea][Tamanio].Puntero = 0;
					x = 0;
			        }
				Tot_Frut_Salidas[E_Salidas_CCM[Linea][Tamanio].Salida_Actual] = 0;					/* pongo a cero el total de frutos por salida actual */
				Bandeja_Aux = E_Salidas_CCM[Linea][Tamanio].Salida_Actual;							/* Guardo el Nº de salida de Bandeja que debo activar */
				E_Salidas_CCM[Linea][Tamanio].Salida_Actual = E_Salidas_CCM[Linea][Tamanio].Sal[x];		/* Actualizo la salida */
				E_Salidas_CCM[Linea][Tamanio].Total_frutos = 0;										/* pongo a cero el total de frutos */
		    	Tot_Frut_Salidas[E_Salidas_CCM[Linea][Tamanio].Salida_Actual] = 0;					/* pongo a cero el total de frutos por salida siguiente */

			/* actualizo todas las lineas con los mismos datos */
			    for(x_linea = 0; x_linea < Config.n_lineas; x_linea ++)							/* Barro por Linea */
			       	{
		    		for(X_Box = 0; X_Box < 4; X_Box ++)											/* Barro los 4 Box */
						{
    					if(E_Salidas_CCM[Linea][Tamanio].Salida_Actual ==  E_Salidas_CCM[x_linea][Tamanio].Sal[X_Box])
							{
    						E_Salidas_CCM[x_linea][Tamanio].Salida_Actual = E_Salidas_CCM[Linea][Tamanio].Salida_Actual;/* Actualizo la salida */
    						E_Salidas_CCM[x_linea][Tamanio].Total_frutos = 0;										/* pongo a cero el total de frutos */
    						E_Salidas_CCM[x_linea][Tamanio].Puntero = E_Salidas_CCM[Linea][Tamanio].Puntero;			/* igualo el puntero */
    						E_Salidas_CCM[x_linea][Tamanio].Cant_Boxes = E_Salidas_CCM[Linea][Tamanio].Cant_Boxes;
    						E_Salidas_CCM[x_linea][Tamanio].Sal[X_Box] = E_Salidas_CCM[Linea][Tamanio].Sal[X_Box];
							}
					 	}
			    	}
			    }
			}
		resultado = E_Salidas_CCM[Linea][Tamanio].Salida_Actual;
		}
	return resultado;
    }

/*---------------------------------------------------------------------------*/
/* Rutina   	: Guardo_Datos
*  Objetivo 	:
*  Entrada  	:
*  Descripcion  : Lo primero que hago es levantar la velocidad:
                    Velocidad == 0 ==> no hago nada
                    Velocidad != 0 ==> realizo la actualización de datos

				El número de máquina va de 1 a 8 OJO no de 0 a 7
						peso neto L1 ==> 2 bytes en binario Del Conversor AD0.
                        peso neto L2 ==> 2 bytes en binario Del Conversor AD0.
                        peso neto L3 ==> 2 bytes en binario Del Conversor AD0.
                        peso neto L4 ==> 2 bytes en binario Del Conversor AD0.
                        peso neto L5 ==> 2 bytes en binario Del Conversor AD0, ó del Conversor AD1 si son 8 líneas.
                        peso neto L6 ==> 2 bytes en binario Del Conversor AD0, ó del Conversor AD1 si son 8 líneas.
                        peso neto L7 ==> 2 bytes en binario Del Conversor AD1.
                        peso neto L8 ==> 2 bytes en binario Del Conversor AD1.
                        Velocidad    ==> 2 bytes en binario --> int16_t Velocidad_medida

		Tamaño 0	-->		pesos negativos.			(No se usan)			T0
		Tamaño 1	-->		desde 0 gr. al 1er. límite	(Se descartan)			T0
		Tamaño 2	-->		desde 1er. límite al 2do. límite					T1
		Tamaño 3	-->		desde 2do. límite al 3er. límite					T2
		Tamaño ..	-->		desde 3er. límite al n. límite
		Tamaño 20	-->		desde n. límite al límite 20.						T19
		Tamaño 21	-->		desde límite 20. al límite 21.(999 gr.)				T20

		El T0 no se usa para nada, se descarta
-----------------------------------------------------------------------------*/
void Guardo_Datos(void)
    {
	int16_t j;
	int16_t y;
	int16_t Peso;

	if(M_Trabajo.Velocidad != 0) 				/* si la máquina está parada, no hago nada */
        {
        for (y = 0; y < Config.n_lineas; y++)	/* Recorro todas las líneas. max --> 8 */
            {  									/* Cargo el peso y el tamaño */
        	Peso = Peso_Neto_CH[y];				/* Traigo los datos de peso ya corregidos del A/D*/

	        j = Calculo_Tamanio(Peso,y);			/* Busco el tamaño correspondiente al peso */

			if((j <= 0) || (j > 20))           		/* si el valor es negativo o mayor a 20, se descarta */
				Peso = 0;							/* Hago cero al peso negativo */

//			if(Peso_Bruto_CH[y] - Tara[y][Conta_Ejes] <= Correcion_cero)	/* Actualizo la tara del platillo */
//				{
//				Tara[y][Conta_Ejes] = Peso_Bruto_CH[y];
//				}

			M_Trabajo.Tot_Platillos[y]++;		/* Incremento el total de platillos de la línea */

            if(Peso > Peso_min)
                {	/* si hay peso incremento los contadores de frutos y peso por línea y tamaño */
                M_Trabajo.TotalKg_Linea[y] = M_Trabajo.TotalKg_Linea[y] + Peso;
                M_Trabajo.Total_Frutos[y]++;				/* incremento tot. frutos */
					/* Incremento por tamaño, el total de Kg. y tot. de frutos */
                M_Trabajo.TotalKg_Tamano[j][y] = M_Trabajo.TotalKg_Tamano[j][y] + Peso;
                M_Trabajo.Tot_Frutos_Tamanos[j][y]++;		/* incremento tot. frutos por tamaño  */
                }
            else    /* Platos vacios */
                {
                M_Trabajo.Tot_Plato_Vacio[y]++;
				j = 0;						/* asigno el tamaño T0 */
                }
					/* Armo la cola -->  y = Linea (0-7), j = tamaño */
			Val_Salida[y][Puntero_Dato]= Veo_Salida(y,j);	/* Guardo el dato de la salida (Cola) */
			Bandeja[y][Puntero_Dato] = Bandeja_Aux;			/* Guardo el dato de la bandeja a activar */
		    Tamano_E[y][Puntero_Dato_E] = j; 				/* Guardo el dato del tamaño para la etiquetadora */
            }   /* cierro el for de las lineas */
        }       /* cierro el if de la velocidad */
    }

/*---------------------------------------------------------------------------*/
/* Rutina   : Calculo_Tamaño
*  Objetivo :
*  Entrada  :
*  Descripcion :

		Tamaño 0	-->		pesos negativos.			(No se usan)			T0
		Tamaño 1	-->		desde 0 gr. al 1er. límite	(Se descartan)			T0
		Tamaño 2	-->		desde 1er. límite al 2do. límite					T1
		Tamaño 3	-->		desde 2do. límite al 3er. límite					T2
		Tamaño ..	-->		desde 3er. límite al n. límite
		Tamaño 20	-->		desde n. límite al límite 20.						T19
		Tamaño 21	-->		desde límite 20. al límite 21.(999 gr.)				T20

		El T0 no se usa para nada, se descarta
		Aux_Linea va de 0 a 7	-->  número de línea
		retorno el dato calculado
-----------------------------------------------------------------------------*/
int16_t Calculo_Tamanio(int16_t Aux_Peso, int16_t Aux_Linea)	/* calculo el tamaño según el peso del fruto */
	{
	int16_t resultado = 0;
	int16_t x;

	if(Aux_Peso < 0)								/* Si el peso es megativo */
		resultado = 0;
	else
		{
		if(Aux_Peso < Tabla_Limites_CCM[0][Aux_Linea])	/* Si el peso es menor que el 1er límite --> T1 */
			resultado = 0;
		else
			{
			x = 1;
			while(x < Max_Tamanos - 1)
				{
				if((Aux_Peso <= Tabla_Limites_CCM[x][Aux_Linea]) && (Aux_Peso >= Tabla_Limites_CCM[x - 1][Aux_Linea]))
					{
					resultado = x;
					break;
					}
				x = x + 1;
				}
			}
		}
	return(resultado);
	}

/*---------------------------------------------------------------------------*/
/* Rutina   : Armo_Limites
*  Objetivo : Guardar los límites en la Tabla de límites
*  Entrada  :
*  Descripcion :
            Estos son:1.- Comando 0x0C (12)
                      2.- N# de línea OJO va de 1 a 8
                      3.- Limite mas bajo     2 byte en binario (Baja, Alta)
                      4.- Limite que le sigue 2 byte en binario (Baja, Alta)
                      5.- Limite que le sigue 2 byte en binario (Baja, Alta)
                      6.- Limite que le sigue 2 byte en binario (Baja, Alta)
                      7.- Limite que le sigue 2 byte en binario (Baja, Alta)
                      x.- Limite que le sigue 2 byte en binario (Baja, Alta)
                      x.- Limite que le sigue 2 byte en binario (Baja, Alta)
                     20.- Limite que le sigue 2 byte en binario (Baja, Alta)
                     21.- Limite que le sigue 2 byte en binario (Baja, Alta)
                     22.- Limite mas alto     2 byte en binario (Baja, Alta)

					  Se reciben en ASCII.
			Guardo los datos en la variable "Tabla_Limites[x][y]"
			hay que tener en cuenta que la PC envía primer límite = valor menor a pesar T0
			a partir del segundo los valores son el limite superior de cada tamaño y se debe
			agregar como último límite 999 que NO es enviado.
			Al número de línea hay que restale 1 para cargar la tabla de límites
*/
void Armo_Limites(void)
	{
    int8_t Aux[4];
    int16_t j;
    int8_t x;
    int8_t y;

    y = (*(Comunica_PC.buf_rx_PC + 9) & 0x0F) - 1;		/* guardo el Nº de línea */

    for(x = 0; x < Max_Tamanos - 2; x++)				/* Borro los tamaños de la tabla de la línea y */
    	Tabla_Limites_CCM[x][y] = 0; 					/* guardo el límite */

    for(x = 0; x < Max_Tamanos - 2; x++)				/* son 21 límites de 0 a 20, recibo 20 datos y el 21 es 999 */
        {
        Aux[0] = *(Comunica_PC.buf_rx_PC + 10 + (x * 3));/* Paso el ASCII recibido a integer */
        Aux[1] = *(Comunica_PC.buf_rx_PC + 11 + (x * 3));
        Aux[2] = *(Comunica_PC.buf_rx_PC + 12 +( x * 3));
        Aux[3] = Null;
        j = mi_atoi(Aux, 4);							/* Valor del límite 0gr. --> 999gr. */

        Tabla_Limites_CCM[x][y] = j; 					/* guardo el límite */
        }
    Tabla_Limites_CCM[Max_Tamanos - 2][y] = 999; 		/* guardo el último límite que es 999gr. */

    if((y + 1) == Config.n_lineas )                     // cuando llego a la última línea guardo los datos en la RAM BACKUP
         Flg_Write = true;					            // Pongo el flag para grabar en la flash

	}

/*---------------------------------------------------------------------------*/
/* Rutina   :   Trans_Totales
*  Objetivo :   Transfiero a la PC los datos de los totales generales
*  Entrada  :
*  Descripcion :
-----------------------------------------------------------------------------*/
void Trans_Totales(void)
    {
    switch(N_Transferencia)
        {
         case 0:
         	Borro_totalizadores(1); 	/* transfiero los datos a la estructura de transmisión */
            Paquete_Tamanio(0, 0);
            break;
         case 1:
            Paquete_Tamanio(0, 5);
            break;
         case 2:
            Paquete_Tamanio(0, 10);
            break;
         case 3:
            Paquete_Tamanio(0, 15);
            break;
         case 4:
            Paquete_Tamanio(1, 0);
            break;
         case 5:
            Paquete_Tamanio(1, 5);
            break;
         case 6:
            Paquete_Tamanio(1, 10);
            break;
         case 7:
            Paquete_Tamanio(1, 15);
            break;
         case 8:
            Paquete_Tamanio(2, 0);
            break;
         case 9:
            Paquete_Tamanio(2, 5);
            break;
         case 10:
            Paquete_Tamanio(2, 10);
            break;
         case 11:
            Paquete_Tamanio(2, 15);
            break;
         case 12:
            Paquete_Tamanio(3, 0);
            break;
         case 13:
            Paquete_Tamanio(3, 5);
            break;
         case 14:
            Paquete_Tamanio(3, 10);
            break;
         case 15:
            Paquete_Tamanio(3, 15);
            break;
         case 16:
            Paquete_Tamanio(4, 0);
            break;
         case 17:
            Paquete_Tamanio(4, 5);
            break;
         case 18:
            Paquete_Tamanio(4, 10);
            break;
         case 19:
            Paquete_Tamanio(4, 15);
            break;
         case 20:
            Paquete_Tamanio(5, 0);
            break;
         case 21:
            Paquete_Tamanio(5, 5);
            break;
         case 22:
            Paquete_Tamanio(5, 10);
            break;
         case 23:
            Paquete_Tamanio(5, 15);
            break;

         case 24:
            Paquete_Varios1();
            break;
         case 25:
            Paquete_Varios2();
            break;
         case 26:
            Paquete_Varios3();
            break;
         case 27:
            Paquete_Varios4();
            break;

         case 28:
            Paquete_Fruta(0, 0);
            break;
         case 29:
            Paquete_Fruta(0, 5);
            break;
         case 30:
            Paquete_Fruta(0, 10);
            break;
         case 31:
            Paquete_Fruta(0, 15);
            break;
         case 32:
            Paquete_Fruta(1, 0);
            break;
         case 33:
            Paquete_Fruta(1, 5);
            break;
         case 34:
            Paquete_Fruta(1, 10);
            break;
         case 35:
            Paquete_Fruta(1, 15);
            break;
         case 36:
            Paquete_Fruta(2, 0);
            break;
         case 37:
            Paquete_Fruta(2, 5);
            break;
         case 38:
            Paquete_Fruta(2, 10);
            break;
         case 39:
            Paquete_Fruta(2, 15);
            break;
         case 40:
            Paquete_Fruta(3, 0);
            break;
         case 41:
            Paquete_Fruta(3, 5);
            break;
         case 42:
            Paquete_Fruta(3, 10);
            break;
         case 43:
            Paquete_Fruta(3, 15);
            break;
         case 44:
            Paquete_Fruta(4, 0);
            break;
         case 45:
            Paquete_Fruta(4, 5);
            break;
         case 46:
            Paquete_Fruta(4, 10);
            break;
         case 47:
            Paquete_Fruta(4, 15);
            break;
         case 48:
            Paquete_Fruta(5, 0);
            break;
         case 49:
            Paquete_Fruta(5, 5);
            break;
         case 50:
            Paquete_Fruta(5, 10);
            break;
         case 51:
            Paquete_Fruta(5, 15);
			N_Transferencia = 0;
            break;
        }
    }

/*---------------------------------------------------------------------------*/
/* Rutina   :   Paquete_Tamanio
*  Objetivo :   Transfiero a la PC los totales generales de los Kg. por tamaños
*  Entrada  :
*  Descripcion : El string a transmitir debe ser:

     [stx][nodo dest.][nodo origen][long][N#Comunicacion][       dato   1       ]......[       dato   5        ][ck]
       0     1  2         3  4       5 6      7  8        9 10 11 12 13 14 15 16 .......41 42 43 44 45 46 47 48  49
       stx                              ==>  1 Byte
       nodo dest.						==>  2 bytes
       nodo origen						==>  2 bytes
	   Longitud del paquete = 43        ==>  2 Bytes
       N# de transaccion de 1 a 27      ==>  2 Byte
       son 5 datos de 8 bytes cada uno  ==> 40 Bytes
       Check sum                        ==>  1 Byte
                                           -----------
       Total                            ==> 50 Bytes

	   Solo se transmiten los tamaños del 1 al 20 (son los útiles)
	   total de kg 99.000,000	por tamaño
-----------------------------------------------------------------------------*/
void Paquete_Tamanio(int8_t Linea, int8_t Paquete)
    {
	int8_t x;
    uint32_t aux;
    uint8_t dato[12];

	/* Armo el string a transferir */
    Armo_Cabecera(Comu_PC);					/* Armo la cabecera de la transmisi�n */
    *(Comunica_PC.buf_tx_PC + 5) = '4';            /* Longitud a transmitir */
    *(Comunica_PC.buf_tx_PC + 6) = '3';

    aux = N_Transferencia + 1;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);		/* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 7) = dato[3];
    *(Comunica_PC.buf_tx_PC + 8) = dato[4];
        for(x = 1; x < 6; x++)				/* cargo de 5 tamaños útiles */
            {
            aux = Aux_Trabajo.TotalKg_Tamano[x + Paquete][Linea];
            mi_ltoa (aux, (int8_t *) &dato[0], 10, false);  /* Convierto el INT a ASCII */
            *(Comunica_PC.buf_tx_PC + (x*8) + 1) = dato[2];
            *(Comunica_PC.buf_tx_PC + (x*8) + 2) = dato[3];
            *(Comunica_PC.buf_tx_PC + (x*8) + 3) = dato[4];
            *(Comunica_PC.buf_tx_PC + (x*8) + 4) = dato[5];
            *(Comunica_PC.buf_tx_PC + (x*8) + 5) = dato[6];
            *(Comunica_PC.buf_tx_PC + (x*8) + 6) = dato[7];
            *(Comunica_PC.buf_tx_PC + (x*8) + 7) = dato[8];
            *(Comunica_PC.buf_tx_PC + (x*8) + 8) = dato[9];
            }
        *(Comunica_PC.buf_tx_PC + 49) = Null;      		/* pongo el terminador */

	/* Transmito los datos y calculo el Check sum, lo guardo al final */
    Transmito_string(Comu_PC,true);						/* transmito y calculo en check sum */
    N_Transferencia++;
    }

/*---------------------------------------------------------------------------*/
/* Rutina   :   Paquete_Varios1
*  Objetivo :   Transfiero a la PC los totales generales de los Kg. por l�nea
                y total de frutos. Tiro los gr. de esta forma llego a 999.999Kg.
*  Entrada  :
*  Descripcion :    TotalKg_Linea   ==> 6 datos de 6 bytes  = 36 bytes

                El string a transmitir debe ser:

     [stx][nodo dest.][nodo origen][long][N#Comunicacion][    dato   1    ]....[     dato  6     ][ck]
       0     1  2         3  4       5 6     7  8         9 10 11 12 13 14 .... 39 40 41 42 43 44  45
       stx                              ==>  1 Byte
       nodo dest.						==>  2 bytes
       nodo origen						==>  2 bytes
       Longitud del paquete = 39        ==>  2 Bytes
       N# de transaccion de 1 a 28      ==>  2 Byte
       son 6 datos de 6 bytes cada uno  ==> 36 Bytes
       Check sum                        ==>  1 Byte
                                           -----------
       Total                            ==> 46 Bytes
-----------------------------------------------------------------------------*/
void Paquete_Varios1(void)
    {
	int8_t x;
    uint32_t aux;
    uint8_t dato[11];

	/* Armo el string a transferir */
    Armo_Cabecera(Comu_PC);								/* Armo la cabecera de la transmisi�n */
    *(Comunica_PC.buf_tx_PC + 5) = '3';            			/* Longitud a transmitir */
    *(Comunica_PC.buf_tx_PC + 6) = '9';

    aux = N_Transferencia + 1;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);				/* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 7) = dato[3];
    *(Comunica_PC.buf_tx_PC + 8) = dato[4];
    for(x = 0; x < 6; x++)
        {
        aux = Aux_Trabajo.TotalKg_Linea[x]/1000; 	/* tiro los gr. de esta forma llego a 999.999Kg. */
        mi_ltoa (aux, (int8_t *) &dato[0], 10, false);  			/* Convierto el Long a ASCII */
        *(Comunica_PC.buf_tx_PC + 9 + (x * 6)) = dato[4];
        *(Comunica_PC.buf_tx_PC + 10 + (x * 6)) = dato[5];
        *(Comunica_PC.buf_tx_PC + 11 + (x * 6)) = dato[6];
        *(Comunica_PC.buf_tx_PC + 12 + (x * 6)) = dato[7];
        *(Comunica_PC.buf_tx_PC + 13 + (x * 6)) = dato[8];
        *(Comunica_PC.buf_tx_PC + 14 + (x * 6)) = dato[9];
        }
      /* Transmito los datos y calculo el Check sum, lo guardo al final por si
        necesito retransmisi�n del dato */
    *(Comunica_PC.buf_tx_PC + 45) = Null;      /* pongo el terminador */
    Transmito_string(Comu_PC,true);							/* transmito y calculo en check sum */
    N_Transferencia++;
    }
/*---------------------------------------------------------------------------*/
/* Rutina   :   Paquete_Varios2
*  Objetivo :   Transfiero a la PC los totales de frutos por l�nea.
*  Entrada  :
*  Descripcion :    Total_Frutos    ==> 6 datos de 6 bytes  = 36 bytes
					Total_Frutos = 999.999
                El string a transmitir debe ser:

     [stx][nodo dest.][nodo origen][long][N#Comunicacion][    dato   1    ]....[     dato  6     ][ck]
       0     1  2         3  4       5 6     7  8         9 10 11 12 13 14 .... 39 40 41 42 43 44  45
       stx                              ==>  1 Byte
       nodo dest.						==>  2 bytes
       nodo origen						==>  2 bytes
       Longitud del paquete = 39        ==>  2 Bytes
       N# de transaccion de 1 a 28      ==>  2 Byte
       son 6 datos de 6 bytes cada uno  ==> 36 Bytes
       Check sum                        ==>  1 Byte
                                           -----------
       Total                            ==> 46 Bytes
-----------------------------------------------------------------------------*/
void Paquete_Varios2(void)
    {
	int8_t x;
    uint32_t aux;
    uint8_t dato[11];

	/* Armo el string a transferir */
    Armo_Cabecera(Comu_PC);					/* Armo la cabecera de la transmisi�n */
    *(Comunica_PC.buf_tx_PC + 5) = '3';            /* Longitud a transmitir */
    *(Comunica_PC.buf_tx_PC + 6) = '9';

    aux = N_Transferencia + 1;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);  /* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 7) = dato[3];
    *(Comunica_PC.buf_tx_PC + 8) = dato[4];
    for(x = 0; x < 6; x++)
        {
        aux = Aux_Trabajo.Total_Frutos[x];
        mi_ltoa (aux, (int8_t *) &dato[0], 10, false);  			/* Convierto el Long a ASCII */
         *(Comunica_PC.buf_tx_PC + 9 + (x * 6)) = dato[4];
         *(Comunica_PC.buf_tx_PC + 10 + (x * 6)) = dato[5];
         *(Comunica_PC.buf_tx_PC + 11 + (x * 6)) = dato[6];
         *(Comunica_PC.buf_tx_PC + 12 + (x * 6)) = dato[7];
         *(Comunica_PC.buf_tx_PC + 13 + (x * 6)) = dato[8];
         *(Comunica_PC.buf_tx_PC + 14 + (x * 6)) = dato[9];
          }
      /* Transmito los datos y calculo el Check sum, lo guardo al final por si
        necesito retransmisi�n del dato */
    *(Comunica_PC.buf_tx_PC + 45) = Null;      /* pongo el terminador */
    Transmito_string(Comu_PC,true);							/* transmito y calculo en check sum */
    N_Transferencia++;
    }

/*---------------------------------------------------------------------------*/
/* Rutina   :   Paquete_Varios3
*  Objetivo :   Transfiero a la PC los totales de los platillos vacios.
*  Entrada  :
*  Descripcion :    Tot_Plato_Vacio   ==> 6 datos de 6 bytes  = 36 bytes

                El string a transmitir debe ser:

     [stx][nodo dest.][nodo origen][long][N#Comunicacion][    dato   1    ]....[     dato  6     ][ck]
       0     1  2         3  4       5 6     7  8         9 10 11 12 13 14 .... 39 40 41 42 43 44  45
       stx                              ==>  1 Byte
       nodo dest.						==>  2 bytes
       nodo origen						==>  2 bytes
       Longitud del paquete = 39        ==>  2 Bytes
       N# de transaccion de 1 a 28      ==>  2 Byte
       son 6 datos de 6 bytes cada uno  ==> 36 Bytes
       Check sum                        ==>  1 Byte
                                           -----------
       Total                            ==> 46 Bytes
-----------------------------------------------------------------------------*/
void Paquete_Varios3(void)
    {
	int8_t x;
    uint32_t aux;
    uint8_t dato[11];

	/* Armo el string a transferir */
    Armo_Cabecera(Comu_PC);					/* Armo la cabecera de la transmisi�n */
    *(Comunica_PC.buf_tx_PC + 5) = '3';            /* Longitud a transmitir */
    *(Comunica_PC.buf_tx_PC + 6) = '9';

    aux = N_Transferencia + 1;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);  /* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 7) = dato[3];
    *(Comunica_PC.buf_tx_PC + 8) = dato[4];
    for(x=0; x < 6; x++)
        {
        aux = Aux_Trabajo.Tot_Plato_Vacio[x];
        mi_ltoa (aux, (int8_t *) &dato[0], 10, false);  			/* Convierto el Long a ASCII */
         *(Comunica_PC.buf_tx_PC + 9 + (x * 6)) = dato[4];
         *(Comunica_PC.buf_tx_PC + 10 + (x * 6)) = dato[5];
         *(Comunica_PC.buf_tx_PC + 11 + (x * 6)) = dato[6];
         *(Comunica_PC.buf_tx_PC + 12 + (x * 6)) = dato[7];
         *(Comunica_PC.buf_tx_PC + 13 + (x * 6)) = dato[8];
         *(Comunica_PC.buf_tx_PC + 14 + (x * 6)) = dato[9];
          }
      /* Transmito los datos y calculo el Check sum, lo guardo al final por si
        necesito retransmisi�n del dato */
    *(Comunica_PC.buf_tx_PC + 45) = Null;      /* pongo el terminador */
    Transmito_string(Comu_PC,true);							/* transmito y calculo en check sum */
    N_Transferencia++;
    }

/*---------------------------------------------------------------------------*/
/* Rutina   :   Paquete_Varios4
*  Objetivo :   Transfiero a la PC los totales de los platillos por línea y la
*				velocidad de máquina.
*  Entrada  :
*  Descripcion :    Tot_Platillos   ==> 6 datos de 6 bytes  = 36 bytes
					Velocidad		==> 1 dato de 5 bytes
                El string a transmitir debe ser:

[stx][nodo dest.][nodo origen][long][N#Comunicacion][    dato   1    ]....[     dato  6     ][  velocidad  ][ck]
  0     1  2         3  4       5 6     7  8         9 10 11 12 13 14 .... 39 40 41 42 43 44  45 46 47 48 49 50
       stx                              ==>  1 Byte
       nodo dest.						==>  2 bytes
       nodo origen						==>  2 bytes
       Longitud del paquete = 44        ==>  2 Bytes
       N# de transaccion de 1 a 28      ==>  2 Byte
       son 6 datos de 6 bytes cada uno  ==> 36 Bytes
       Velocidad de la máquina          ==>  5 Bytes
       Check sum                        ==>  1 Byte
                                           -----------
       Total                            ==> 51 Bytes
-----------------------------------------------------------------------------*/
void Paquete_Varios4(void)
    {
	int8_t x;
    uint32_t aux;
    uint8_t dato[11];

	/* Armo el string a transferir */
    Armo_Cabecera(Comu_PC);					/* Armo la cabecera de la transmisi�n */
    *(Comunica_PC.buf_tx_PC + 5) = '4';            /* Longitud a transmitir */
    *(Comunica_PC.buf_tx_PC + 6) = '4';

    aux = N_Transferencia + 1;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);  /* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 7) = dato[3];
    *(Comunica_PC.buf_tx_PC + 8) = dato[4];
    for(x = 0; x < 6; x++)
        {
        aux = Aux_Trabajo.Tot_Platillos[x];
        mi_ltoa (aux, (int8_t *) &dato[0], 10, false);  			/* Convierto el Long a ASCII */
         *(Comunica_PC.buf_tx_PC + 9 + (x * 6)) = dato[4];
         *(Comunica_PC.buf_tx_PC + 10 + (x * 6)) = dato[5];
         *(Comunica_PC.buf_tx_PC + 11 + (x * 6)) = dato[6];
         *(Comunica_PC.buf_tx_PC + 12 + (x * 6)) = dato[7];
         *(Comunica_PC.buf_tx_PC + 13 + (x * 6)) = dato[8];
         *(Comunica_PC.buf_tx_PC + 14 + (x * 6)) = dato[9];
         }

	aux = Aux_Trabajo.Velocidad;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);  			/* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 45) = dato[0];
    *(Comunica_PC.buf_tx_PC + 46) = dato[1];
    *(Comunica_PC.buf_tx_PC + 47) = dato[2];
    *(Comunica_PC.buf_tx_PC + 48) = dato[3];
    *(Comunica_PC.buf_tx_PC + 49) = dato[4];
      /* Transmito los datos y calculo el Check sum, lo guardo al final por si
        necesito retransmisión del dato */
    *(Comunica_PC.buf_tx_PC + 50) = Null;      				/* pongo el terminador */
    Transmito_string(Comu_PC,true);							/* transmito y calculo en check sum */
    N_Transferencia++;
    }
/*---------------------------------------------------------------------------*/
/* Rutina   :   Paquete_Fruta
*  Objetivo :   Transfiero a la PC los totales generales de frutos por tama�os
*  Entrada  :
*  Descripcion : El string a transmitir debe ser:

     [stx][nodo dest.][nodo origen][long][N#Comunicacion][    dato   1    ]....[     dato  5     ][ck]
       0     1  2         3  4       5 6     7  8         9 10 11 12 13 14 .... 33 34 35 36 37 38  39
       stx                              ==>  1 Byte
       nodo dest.						==>  2 bytes
       nodo origen						==>  2 bytes
       Longitud del paquete = 63        ==>  2 Bytes
       N# de transaccion de 1 a 6       ==>  2 Byte
       son 5 datos de 6 bytes cada uno  ==> 30 Bytes
       Check sum                        ==>  1 Byte
                                           -----------
       Total                            ==> 40 Bytes
-----------------------------------------------------------------------------*/
void Paquete_Fruta(int8_t Linea, int8_t Paquete)
    {
	int8_t x;
    uint32_t aux;
    uint8_t dato[11];

	/* Armo el string a transferir */
    Armo_Cabecera(Comu_PC);					/* Armo la cabecera de la transmisi�n */
    *(Comunica_PC.buf_tx_PC + 5) = '3';            /* Longitud a transmitir */
    *(Comunica_PC.buf_tx_PC + 6) = '3';

    aux = N_Transferencia + 1;
    mi_itoa (aux, (int8_t *) &dato[0], 5, false);  /* Convierto el INT a ASCII */
    *(Comunica_PC.buf_tx_PC + 7) = dato[3];
    *(Comunica_PC.buf_tx_PC + 8) = dato[4];
        for(x=1; x<6; x++)
            {
            aux = Aux_Trabajo.Tot_Frutos_Tamanos[x + Paquete][Linea];
            mi_ltoa (aux, (int8_t *) &dato[0], 10, false);  			/* Convierto el Long a ASCII */
            *(Comunica_PC.buf_tx_PC + (x*6)+3) = dato[4];
            *(Comunica_PC.buf_tx_PC + (x*6)+4) = dato[5];
            *(Comunica_PC.buf_tx_PC + (x*6)+5) = dato[6];
            *(Comunica_PC.buf_tx_PC + (x*6)+6) = dato[7];
            *(Comunica_PC.buf_tx_PC + (x*6)+7) = dato[8];
            *(Comunica_PC.buf_tx_PC + (x*6)+8) = dato[9];
            }
      /* Transmito los datos y calculo el Check sum, lo guardo al final por si
        necesito retransmisi�n del dato */
    *(Comunica_PC.buf_tx_PC + 39) = Null;      				/* pongo el terminador */
    Transmito_string(Comu_PC,true);							/* transmito y calculo en check sum */
    N_Transferencia++;
    }
